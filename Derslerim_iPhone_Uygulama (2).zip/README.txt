Derslerim — iPhone Web App

1. Bu klasörü HTTPS çalışan bir web sunucusuna yükle.
2. iPhone'da Safari ile index.html adresini aç.
3. Paylaş -> Ana Ekrana Ekle seç.
4. Ana ekrandaki simge, gönderdiğin kedi fotoğrafıdır.

Not: HTML dosyasını yalnızca Dosyalar uygulamasından açmak, gerçek PWA kurulumunun tüm özelliklerini sağlamaz. En sorunsuz yöntem HTTPS üzerinden yayınlamaktır.
